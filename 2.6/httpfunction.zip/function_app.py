from logging import getLogger
import azure.functions as func
from azure.storage.queue import QueueClient, TextBase64EncodePolicy
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import trace, propagate
import os
import json

# Use the AzureWebJobsStorage environment variable for the connection string
connection_string = os.getenv("AzureWebJobsStorage")
queue_name = "orderqueue"

queue_client = QueueClient.from_connection_string(
    conn_str=connection_string,
    queue_name=queue_name,
    message_encode_policy=TextBase64EncodePolicy()
)

configure_azure_monitor(
    logger_name=__name__,
)

logger = getLogger(__name__)
logger.propagate = False

tracer = trace.get_tracer(__name__)

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)
@app.route(route="http_trigger")

def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    with tracer.start_as_current_span("HTTP Trigger Function") as span:
        try:
            order_data = req.get_json()

            carrier = {}
            propagate.inject(carrier) 

            # Log the order
            logger.info(f"Received order: {order_data}")

            message = json.dumps({"order": order_data, "trace_context": carrier})

            # Add message to the queue
            queue_client.send_message(message, time_to_live=3600)
            logger.info("Message sent to queue")

            span.set_attribute("http.method", "POST")
            span.set_attribute("http.status_code", 200)
            return func.HttpResponse("Order received", status_code=200)

        except Exception as e:
            logger.error(f"Error processing order: {e}")
            span.record_exception(e)
            return func.HttpResponse("Internal Server Error", status_code=500)
