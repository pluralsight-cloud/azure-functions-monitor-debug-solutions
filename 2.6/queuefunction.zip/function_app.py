from logging import getLogger
import azure.functions as func
from azure.cosmos import CosmosClient
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import trace, propagate
import os
import json

# Initialize logger with Azure Monitor
configure_azure_monitor(logger_name=__name__)
logger = getLogger(__name__)
logger.propagate = False

# Retrieve Cosmos DB connection string from environment variable
cosmos_conn_str = os.getenv("COSMOS_DB_CONNECTION_STRING")
cosmos_client = CosmosClient.from_connection_string(cosmos_conn_str)

# Define DB and container names (replace if needed)
database_name = "OrdersDB"
container_name = "Orders"

database = cosmos_client.get_database_client(database_name)
container = database.get_container_client(container_name)

app = func.FunctionApp()

tracer = trace.get_tracer(__name__)

@app.function_name(name="QueueFunc")
@app.queue_trigger(arg_name="msg", queue_name="orderqueue",
                   connection="AzureWebJobsStorage")  # Queue trigger

def queue_trigger(msg: func.QueueMessage) -> None:
    # Decode message from queue
    message_body = msg.get_body().decode("utf-8")

    # Optional: parse as JSON if your data format requires
    order_data = json.loads(message_body)

    carrier = order_data.get("trace_context", {})

    # extract() returns a Context containing the upstream trace info
    ctx = propagate.extract(carrier)

    with tracer.start_as_current_span("Queue Trigger Function", context=ctx) as span:
        try:

            logger.info(f"Received message from queue: {message_body}")

            # Write to Cosmos DB
            container.upsert_item({
                "id": msg.id,  # unique ID per message
                "order": order_data
            })
            logger.info("Order written to Cosmos DB")

            # Add tracing metadata
            span.set_attribute("queue.message_id", msg.id)
            span.set_attribute("cosmosdb.status", "success")

        except Exception as e:
            logger.error(f"Error processing message from queue: {e}")
            span.record_exception(e)
