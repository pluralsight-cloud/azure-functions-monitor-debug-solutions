import json
import logging
import azure.functions as func
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import metrics

configure_azure_monitor(logger_name=__name__)
logger = logging.getLogger(__name__)


meter = metrics.get_meter(__name__)

order_value_hist = meter.create_histogram(
    name="ecommerce.order_value",      # appears as a custom metric
    unit="USD",
    description="Total order value for each checkout",
)

items_per_order_hist = meter.create_histogram(
    name="ecommerce.items_per_order",
    unit="items",
    description="Number of items per completed order",
)



app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="checkout")
def checkout(req: func.HttpRequest) -> func.HttpResponse:
    """
    POST /api/checkout
    Body: {
      "orderId":   "A123",
      "customerId":"C001",
      "items": [
         {"sku":"LAPTOP-17", "qty":1, "price":1299},
         {"sku":"MOUSE-BLK", "qty":2, "price":25}
      ]
    }
    """
    # --- validate JSON -----------------------------------------------------
    try:
        body = req.get_json()
    except ValueError:
        logger.warning(
            "Bad JSON payload",
            extra={"microsoft.custom_event.name": "InvalidCheckoutPayload"}
        )
        return func.HttpResponse("Invalid JSON", status_code=400)

    order_id   = body.get("orderId")
    customer   = body.get("customerId")
    items      = body.get("items", [])

    if not order_id or not items:
        logger.warning(
            "Missing mandatory fields",
            extra={
                "microsoft.custom_event.name": "CheckoutValidationFailed",
                "orderId": order_id,
            }
        )
        return func.HttpResponse("orderId and items required", status_code=400)

    # --- business logic ----------------------------------------------------
    total_value = sum(i.get("price", 0) * i.get("qty", 1) for i in items)
    item_count  = sum(i.get("qty", 1) for i in items)

    # --- emit custom metrics ----------------------------------------------
    order_value_hist.record(total_value, attributes={"currency": "USD"})
    items_per_order_hist.record(item_count)

    # --- emit custom event -------------------------------------------------
    logger.info(
        "Checkout completed",
        extra={
            "microsoft.custom_event.name": "CheckoutCompleted",
            "orderId":   order_id,
            "customerId": customer,
            "orderValue": total_value,
            "itemCount":  item_count,
        },
    )

    # --- respond -----------------------------------------------------------
    return func.HttpResponse(
        json.dumps(
            {
                "status":  "accepted",
                "orderId": order_id,
                "total":   total_value,
            }
        ),
        mimetype="application/json",
        status_code=202,
    )