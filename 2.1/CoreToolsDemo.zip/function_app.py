import azure.functions as func
import logging
import json
import os

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="get_sales")
def get_sales(req: func.HttpRequest) -> func.HttpResponse:
    """
    GET /api/GetSales
    """
    logging.info("GetSales function invoked")

    conn_str = os.getenv("ConnectionStrings_SalesDb")

    server_kv = next(
        kv for kv in conn_str.split(";") if kv.lower().startswith("server=")
        )

    # Simulated data fetch
    sales = [
        {"id": 1, "item": "Laptop", "amount": 1_299},
        {"id": 2, "item": "Mouse",  "amount": 25},
    ]

    return func.HttpResponse(
        json.dumps(sales),
        status_code=200,
        mimetype="application/json",
    )
