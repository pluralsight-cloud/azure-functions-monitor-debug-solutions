using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace SnapshotDemo
{
    public static class GetSales
    {
        [FunctionName("GetSales")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("GetSales triggered");

            // Parse ?limit=  (defaults to 10)
            if (!int.TryParse(req.Query["limit"], out var limit))
            {
                return new BadRequestObjectResult("'limit' must be an integer.");
            }

            // Deliberate bug – DivideByZeroException when limit == 0
            int pageSize = 100 / limit;

            var sales = new[]
            {
                new { id = 1, item = "Laptop", amount = 1299 },
                new { id = 2, item = "Mouse",  amount = 25  }
            };

            return new OkObjectResult(new { pageSize, sales });
        }
    }
}
