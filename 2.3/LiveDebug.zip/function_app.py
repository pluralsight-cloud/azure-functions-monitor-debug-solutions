import azure.functions as func
import logging
import json

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="validate_order")
def validate_order(req: func.HttpRequest) -> func.HttpResponse:
    try:
        payload = req.get_json()
    except ValueError:
        logging.error("Invalid JSON")
        return func.HttpResponse("Bad JSON", status_code=400)

    order_id = payload.get("orderId")
    qty      = payload.get("quantity")

    if not order_id or qty is None:
        logging.warning("Missing field(s). orderId=%s qty=%s", order_id, qty)
        return func.HttpResponse("orderId and quantity required", status_code=400)

    if qty <= 0:
        logging.error("Quantity must be > 0. orderId=%s qty=%s", order_id, qty)
        raise ValueError("Quantity must be positive")

    logging.info("Order accepted. orderId=%s qty=%s", order_id, qty)
    return func.HttpResponse(
        json.dumps({"status": "accepted", "orderId": order_id, "qty": qty}),
        mimetype="application/json",
    )