import azure.functions as func
import logging
import json
# import hashlib  ← deleted on purpose!

CACHE = {}

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="get_sales")
def get_sales(req: func.HttpRequest) -> func.HttpResponse:
    """
    GET /api/get_sales?tenantId=<id>
    Intentionally fails to normalize tenantId, so cache misses every time.
    """
    tenant_id = (req.params.get("tenantId") or "").strip()
    if not tenant_id:
        return func.HttpResponse("'tenantId' required.", status_code=400)

    # Bug: we think we’re hashing, but hashlib is missing, so we fallback
    # to a simple (and case-sensitive) key.
    cache_key = tenant_id          # ← subtle culprit

    if cache_key in CACHE:
        log_msg = f"Cache HIT for '{tenant_id}'"
        data = CACHE[cache_key]
    else:
        log_msg = f"Cache MISS for '{tenant_id}' – fetching fresh data"
        # Simulated expensive work
        CACHE[cache_key] = data

    logging.info(log_msg)
    return func.HttpResponse(json.dumps(data), mimetype="application/json")